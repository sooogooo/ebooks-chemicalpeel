# 《刷酸医美：刷出好气色》静态网站

## 📚 关于本书

这是一本专业、系统、实用的刷酸科普指南，总字数超过11.8万字，包含14个章节的完整内容。

## 🚀 部署说明

### 快速部署

1. **解压文件**：将 `release.zip` 解压到服务器目录
2. **配置Web服务器**：将解压后的文件夹设为网站根目录
3. **访问网站**：通过浏览器访问即可

### 支持的Web服务器

- **Nginx**
- **Apache**
- **IIS**
- **Node.js** (使用 serve 等静态文件服务器)
- **Python** (使用 `python -m http.server`)

### 本地预览

```bash
# 使用Python
python -m http.server 8000

# 使用Node.js
npx serve .

# 使用PHP
php -S localhost:8000
```

然后访问 `http://localhost:8000`

## 📱 功能特性

- ✅ 响应式设计，支持手机、平板、电脑
- ✅ 全文搜索功能
- ✅ 明暗主题切换
- ✅ 目录导航
- ✅ 打印友好
- ✅ 离线可用

## 📊 内容统计

- **总字数**: 118,554字
- **章节数**: 14章
- **图表数**: 18个SVG图表
- **附录数**: 4个实用附录

## 🎨 技术栈

- **文档生成**: MkDocs + Material主题
- **样式**: CSS3 + Material Design
- **搜索**: 内置JavaScript搜索
- **图标**: Material Icons
- **字体**: Noto Sans SC

## 📄 版权信息

Copyright © 2025 《刷酸医美：刷出好气色》编写团队

本作品采用知识共享署名-非商业性使用 4.0 国际许可协议进行许可。

## 🔧 技术支持

如有技术问题，请联系：
- 邮箱：contact@chemical-peel-guide.com
- GitHub：https://github.com/chemical-peel-guide

---

*让科学护肤成为一种生活方式* ✨
