#!/bin/bash

echo "🚀 刷酸医美电子书 - 快速部署"
echo "================================"

# 检查Python
if command -v python3 &> /dev/null; then
    echo "✅ 检测到 Python3"
    echo "🌐 启动本地服务器..."
    echo "📱 访问地址: http://localhost:8000"
    echo "⏹️  按 Ctrl+C 停止服务"
    echo ""
    python3 -m http.server 8000
elif command -v python &> /dev/null; then
    echo "✅ 检测到 Python"
    echo "🌐 启动本地服务器..."
    echo "📱 访问地址: http://localhost:8000"
    echo "⏹️  按 Ctrl+C 停止服务"
    echo ""
    python -m http.server 8000
elif command -v node &> /dev/null; then
    echo "✅ 检测到 Node.js"
    if command -v npx &> /dev/null; then
        echo "🌐 启动本地服务器..."
        echo "📱 访问地址: http://localhost:3000"
        echo "⏹️  按 Ctrl+C 停止服务"
        echo ""
        npx serve . -p 3000
    else
        echo "❌ 需要安装 npx"
    fi
else
    echo "❌ 未检测到 Python 或 Node.js"
    echo "请安装 Python3 或 Node.js 后重试"
    echo ""
    echo "安装方法:"
    echo "  Ubuntu/Debian: sudo apt install python3"
    echo "  CentOS/RHEL: sudo yum install python3"
    echo "  macOS: brew install python3"
    echo "  Windows: 从 python.org 下载安装"
fi
